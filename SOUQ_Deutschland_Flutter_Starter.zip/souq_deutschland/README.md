# SOUQ Deutschland — Flutter starter

A black-and-gold marketplace UI starter for Germany and Morocco, with German, Arabic, French and English language switching.

## Build an Android APK
This project requires Flutter 3.3+ and the Android SDK.
1. Install Flutter and Android Studio on a computer, or upload this folder to a GitHub repository.
2. Run `flutter pub get`
3. Run `flutter build apk --release`
4. APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Build from an Android phone
You can use GitHub in your phone browser: create a repository, upload the project files, then use the included GitHub Actions workflow. GitHub Actions requires a GitHub account and repository.

## Important
This is a starter UI, not a production marketplace. It does not yet include login, database, live listings, photo storage, chat, payment processing, subscriptions, seller verification, moderation, privacy/legal pages or backend security. Do not accept payments or publish it as a live marketplace until those are implemented and tested.
