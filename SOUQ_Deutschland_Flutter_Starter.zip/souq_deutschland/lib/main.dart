import 'package:flutter/material.dart';

void main() => runApp(const SouqApp());

class SouqApp extends StatefulWidget {
  const SouqApp({super.key});
  @override
  State<SouqApp> createState() => _SouqAppState();
}

class _SouqAppState extends State<SouqApp> {
  Locale _locale = const Locale('de');
  int _tab = 0;
  String _query = '';

  final Map<String, Map<String, String>> words = {
    'de': {'title':'SOUQ Deutschland','search':'Produkte, Autos und mehr suchen','categories':'Kategorien','all':'Alle','cars':'Autos','home':'Immobilien','phones':'Elektronik','fashion':'Mode','services':'Dienstleistungen','latest':'Neue Anzeigen','sell':'Anzeige aufgeben','favorites':'Merkliste','messages':'Nachrichten','account':'Konto','welcome':'Kaufen und verkaufen – einfach und lokal','location':'Deutschland · Marokko','empty':'Noch keine Anzeigen. Bald findest du hier Angebote.'},
    'ar': {'title':'سوق ألمانيا','search':'ابحث عن منتجات وسيارات والمزيد','categories':'الأقسام','all':'الكل','cars':'سيارات','home':'عقارات','phones':'إلكترونيات','fashion':'ملابس','services':'خدمات','latest':'أحدث الإعلانات','sell':'أضف إعلاناً','favorites':'المفضلة','messages':'الرسائل','account':'حسابي','welcome':'بيع وشراء بسهولة وفي منطقتك','location':'ألمانيا · المغرب','empty':'لا توجد إعلانات حالياً. ستظهر العروض هنا قريباً.'},
    'fr': {'title':'SOUQ Deutschland','search':'Rechercher produits, voitures…','categories':'Catégories','all':'Tout','cars':'Voitures','home':'Immobilier','phones':'Électronique','fashion':'Mode','services':'Services','latest':'Dernières annonces','sell':'Déposer une annonce','favorites':'Favoris','messages':'Messages','account':'Compte','welcome':'Achetez et vendez simplement, près de vous','location':'Allemagne · Maroc','empty':'Aucune annonce pour le moment.'},
    'en': {'title':'SOUQ Deutschland','search':'Search products, cars and more','categories':'Categories','all':'All','cars':'Cars','home':'Property','phones':'Electronics','fashion':'Fashion','services':'Services','latest':'Latest listings','sell':'Post an ad','favorites':'Favorites','messages':'Messages','account':'Account','welcome':'Buy and sell easily, close to you','location':'Germany · Morocco','empty':'No listings yet. Offers will appear here soon.'},
  };
  String t(String key) => words[_locale.languageCode]?[key] ?? words['de']![key]!;

  @override
  Widget build(BuildContext context) {
    final rtl = _locale.languageCode == 'ar';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SOUQ Deutschland',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC9A646), brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F6F2),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF111111), foregroundColor: Color(0xFFD8B65B)),
      ),
      home: Directionality(
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(
          appBar: AppBar(
            title: Text(t('title'), style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: .4)),
            actions: [
              PopupMenuButton<String>(
                tooltip: 'Language',
                icon: const Icon(Icons.language),
                onSelected: (v) => setState(() => _locale = Locale(v)),
                itemBuilder: (_) => const [
                  PopupMenuItem(value:'de', child: Text('🇩🇪 Deutsch')),
                  PopupMenuItem(value:'ar', child: Text('🇲🇦 العربية')),
                  PopupMenuItem(value:'fr', child: Text('🇫🇷 Français')),
                  PopupMenuItem(value:'en', child: Text('🇬🇧 English')),
                ],
              ),
              const SizedBox(width: 8),
            ],
          ),
          body: _tab == 0 ? _home() : _placeholder(),
          floatingActionButton: _tab == 0 ? FloatingActionButton.extended(
            backgroundColor: const Color(0xFFD8B65B), foregroundColor: Colors.black,
            onPressed: () => _showPostInfo(), icon: const Icon(Icons.add), label: Text(t('sell')),
          ) : null,
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              const NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Souq'),
              NavigationDestination(icon: const Icon(Icons.favorite_border), label: t('favorites')),
              NavigationDestination(icon: const Icon(Icons.chat_bubble_outline), label: t('messages')),
              NavigationDestination(icon: const Icon(Icons.person_outline), label: t('account')),
            ],
          ),
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 100),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: const Color(0xFF171717), borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t('welcome'), style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(t('location'), style: const TextStyle(color: Color(0xFFD8B65B))),
        ]),
      ),
      const SizedBox(height: 18),
      TextField(
        onChanged: (v) => setState(() => _query = v),
        decoration: InputDecoration(
          hintText: t('search'), prefixIcon: const Icon(Icons.search),
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 22),
      Text(t('categories'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Wrap(spacing: 9, runSpacing: 9, children: [
        _category(Icons.grid_view, 'all'), _category(Icons.directions_car, 'cars'),
        _category(Icons.home_work_outlined, 'home'), _category(Icons.devices, 'phones'),
        _category(Icons.checkroom, 'fashion'), _category(Icons.handyman_outlined, 'services'),
      ]),
      const SizedBox(height: 24),
      Text(t('latest'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          const Icon(Icons.campaign_outlined, size: 42, color: Color(0xFFC9A646)),
          const SizedBox(height: 8),
          Text(t('empty'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
        ]),
      ),
    ],
  );

  Widget _category(IconData icon, String key) => ActionChip(
    avatar: Icon(icon, size: 18, color: const Color(0xFF9A7929)),
    label: Text(t(key)),
    backgroundColor: Colors.white,
    side: BorderSide.none,
    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${t(key)} — coming soon'))),
  );

  Widget _placeholder() => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Text(t('empty'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 17)),
    ),
  );

  void _showPostInfo() => showDialog<void>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(t('sell')),
      content: const Text('This starter preview does not yet publish listings. User accounts, image upload, messaging, payments and moderation must be connected before launch.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
    ),
  );
}
